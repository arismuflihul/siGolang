// This package hasn't jumped ship yet.
package foo
